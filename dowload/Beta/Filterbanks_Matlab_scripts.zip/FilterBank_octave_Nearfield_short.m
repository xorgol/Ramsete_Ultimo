% generate a perfectly reconstructive filterbank - Octave version +
% Nearfield - shrt (Nh=8192 samples)
close all;
fs=48000; % Sampling Frequency in Hz
Nl=8192; % Filter Length in samples
Nh=8192;
dt=1/fs;  % Sampling interval in s

%Costruisci la finestra
twin = hann(Nh/2);
window = [twin(1:floor(Nh/4));ones(floor(Nh/2),1);twin(floor(Nh/4)+1:floor(Nh/2))];
% window = [window ; zeros(size(yy,3)-size(window,1),1)];

% Costruisci un primo filterbank
octFiltBank = octaveFilterBank('1 octave','FrequencyRange',[125/4,20000],'FilterOrder',6,'SampleRate',fs)
% fvt = fvtool(octFiltBank,"NFFT",2^16);
% set(fvt,FrequencyScale="log")
% zoom(fvt,[.01 24 -20 1])
x=zeros(Nl,1);
x(4095,1)=1;
y = octFiltBank(x);
% audiowrite('Filterbank_1Oct.wav',y,fs,'BitsPerSample',32);

% compute time-reversed filterbank
xx=zeros(Nl*2,10);
for i=1:Nl
    xx(i,:)=y(Nl+1-i,:);
end

% convolve the reversed filterbank xx with the original one y
yy=zeros(Nl*2,10);
for ch=1:10
    yy(:,ch)=fftfilt(y(:,ch),xx(:,ch));
end
yy=yy(Nl/2:(Nl+Nl/2-1),:);
% audiowrite('Filterbank_1Oct_2.wav',yy,fs,'BitsPerSample',32);

% Downmix to mono
z= zeros(Nl,1);
for ch=1:10
    z(:,1)=z(:,1)+yy(:,ch);
end
% audiowrite('Dirac_Reconstructed_1.wav',z,fs,'BitsPerSample',32);

%Applica la finestra fade-in e fade-out
% z = z.*window;

% perform Kirkeby inversion of z
fl = 10; fh=24000;
bt = 0.33;
Bol = 1; Boh= 1E-3; Bi = 1E-3;
h_matrix = invert_kirkeby(z,fs,fl,fh,bt,Bol,Boh,Bi,Nl*2);
% audiowrite('Eq_Filter_1.wav',h_matrix,fs,'BitsPerSample',32);

% Now let's repeat everything starting with this inverse filter instead of the original Dirac's Delta function
% compute the equalised fiterbank yeq
yeq = octFiltBank(h_matrix);
% audiowrite('Filterbank_1Oct_eq.wav',yeq,fs,'BitsPerSample',32);

% compute time-reversed equalised filterbank
for i=1:Nl
    xx(i,:)=yeq(Nl+1-i,:);
end

% convolve the reversed equalised filterbank xx with the original one y
yy=zeros(Nl*2,10);
for ch=1:10
    yy(:,ch)=fftfilt(y(:,ch),xx(:,ch));
end
yy=yy(4096:(Nl+4095),:);
yy=2.0*yy;

% Downmix to mono
z0= zeros(Nl,1);
for ch=1:10
    z0(:,1)=z0(:,1)+yy(:,ch);
end
audiowrite('Dirac_Reconstructed.wav',z0,fs,'BitsPerSample',32);

% shorten the filter
Nh=8192;

%display(sprintf('\t- Finestratura dei filtri FIR...'))

%Applica la finestra
zz = zeros(Nh,1);
zz = yy.*window;

% Injecting "Diagonal" flag and save
audiowrite('temp.wav',zz,fs,'BitsPerSample',32);
outputFileName ='Filterbank.wav';
[ retVal, consoleStr ] = dos( sprintf( 'ffmpeg -y -i "%s" -acodec pcm_f32le -metadata IKEY=%d "%s"', "temp.wav", 1, outputFileName ) );
delete( "temp.wav" );

% create A-weighting fiter
% Afilter = weightingFilter('A-weighting','SampleRate',fs)
% y = Afilter(x);
% audiowrite('Filter_A.wav',y,fs,'BitsPerSample',32);

% Now we compute the 5 "short" integrated filterbanks multiplied by 1/jw

% plot the spectrum of the 10 filters
figure;
Z=fft(zz);
semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
xlim([20 fs/2])
ylim([-80 40])
xticks([20 31.5 63 125 250 500 1000 2000 4000 8000 16000 fs/2]);
yticks([-80 -70 -60 -50 -40 -30 -20 -10 0 10 20 30 40]);
title('Gain of the Octave-Bands Reconstrucive Filter Banks');
xlabel('Frequency (Hz)') 
ylabel('Gain (dB)') 
hold on;
for band=2:10
    semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,band))));
end

% Apply the integration filtering c/jw
tmp=zz; % data for 1st iteration
integ=zeros(Nh,5);

% define high pass boundaries for integration filters
% (for limiting gain at low frequency)
hpf=zeros(10,1);
hpf(1)=24; % 31.5 Hz band
hpf(2)=30; % 63 Hz band
hpf(3)=40; % 125 Hz band
hpf(4)=50; % 250 Hz band
hpf(5)=100; % 500 Hz band
hpf(6)=200; % 1000 Hz band
hpf(7)=400; % 2000 Hz band
hpf(8)=800; % 4000 Hz band
hpf(9)=1600; % 8000 Hz band
hpf(10)=3200; % 16000 Hz band
hpf=2.0*hpf;

for ord=1:5
    for band=1:10
        % spectral division by jw,  % with High pass filtering 
        zzz(:,band)=inteFD(tmp(:,band),dt,hpf(band));
    end
    zzz=343*zzz; % c/jw - c=343m/s

    % Applica la finestra
    zzz = zzz.*window;
    tmp=zzz; % data for next iteration, windowed

    % Injecting "Diagonal" flag 
    % and save the integrated filter of given order
    audiowrite('temp.wav',zzz,fs,'BitsPerSample',32);
    outputFileName =strcat('Filterbank',string(ord),'.wav');
    [ retVal, consoleStr ] = dos( sprintf( 'ffmpeg -y -i "%s" -acodec pcm_f32le -metadata IKEY=%d "%s"', "temp.wav", 1, outputFileName ) );
    delete( "temp.wav" );
    
    % Downmix to mono
    z= zeros(Nh,1);
    for ch=1:10
        z(:,1)=z(:,1)+zzz(:,ch);
    end
    integ(:,ord)=z(:,1);
    outputFileName =strcat('Dirac_',string(ord),'_Reconstructed.wav');
    audiowrite(outputFileName,z,fs,'BitsPerSample',32);

    % overplot the spectrum of the 10 filters
    Z=fft(zzz); 
    semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
    for band=2:10
        semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,band))));
    end
end

% plot the spectrum of the summed filters
figure;
Z=fft(z0);
semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
xlim([20 fs/2])
ylim([-80 40])
xticks([20 31.5 63 125 250 500 1000 2000 4000 8000 16000 fs/2]);
yticks([-80 -70 -60 -50 -40 -30 -20 -10 0 10 20 30 40]);
title('Gain of the Integrator Filters');
xlabel('Frequency (Hz)') 
ylabel('Gain (dB)') 
hold on;
for ord=1:5
    Z=fft(integ(:,ord));
    semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
end

% Calculations of Near Field filters F for orders 0 to 5
r=1; % source-receiver distance in m
F0=z0; % Dirac's Delta in the center
F1=z0+1/r*integ(:,1);
F2=z0+3/r*integ(:,1)+3/r^2*integ(:,2);
F3=z0+6/r*integ(:,1)+15/r^2*integ(:,2)+15/r^3*integ(:,3);
F4=z0+10/r*integ(:,1)+45/r^2*integ(:,2)+105/r^3*integ(:,3)+105/r^4*integ(:,4);
F5=z0+15/r*integ(:,1)+105/r^2*integ(:,2)+420/r^3*integ(:,3)+945/r^4*integ(:,4)+945/r^5*integ(:,5);
% plot the spectrum of the Near Field Filters
figure;
Z=fft(F0);
semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
xlim([20 fs/2])
ylim([-10 80])
xticks([20 31.5 63 125 250 500 1000 2000 4000 8000 16000 fs/2]);
yticks([-10 0 10 20 30 40 50 60 70 80]);
title('Gain of Near Field Filters at r=1m');
xlabel('Frequency (Hz)') 
ylabel('Gain (dB)') 
hold on;
Z=fft(F1); semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
Z=fft(F2); semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
Z=fft(F3); semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
Z=fft(F4); semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));
Z=fft(F5); semilogx(fs/Nh*(0:Nh/2-1),20*log10(abs(Z(1:Nh/2,1))));

% Save the reconstructed filters for r=1m
    audiowrite('F1.wav',F1,fs,'BitsPerSample',32);
    audiowrite('F2.wav',F2,fs,'BitsPerSample',32);
    audiowrite('F3.wav',F3,fs,'BitsPerSample',32);
    audiowrite('F4.wav',F4,fs,'BitsPerSample',32);
    audiowrite('F5.wav',F5,fs,'BitsPerSample',32);