%*************************************************************************************************
% invert_kirkeby.m                                                           Lorenzo Chiesi 2009 *
%                                                                                                *
% Questa funzione implementa il processo di sintesi dei filtri FIR necessari per l'elaborazione  * 
% del segnale di un array microfonico mediante l'inversione nel dominio della frequenza          *  
% delle risposte all'impulso misurate sperimentalmente                                           *
% versione semplificata da Angelo farina - 2023
%                                                                                                *
%*************************************************************************************************
%
% h_matrix = invert_kirkeby(c_matrix,Fs,fl,fh,bt,Bol,Boh,Bi,Nh);
%
% c_matrix  = Risposta all'impulso d invertire (Nc)
% fl        = Frequenza di taglio inferiore [Hz]
% fh        = Frequenza di taglio superiore [Hz]
% bt        = Banda di transizione [ottave]
% Bol       = Parametro di regolarizzazione fuori-banda in BF
% Boh       = Parametro di regolarizzazione fuori-banda in HF
% Bi        = Parametro di regolarizzazione in-banda
% Nh        = Lunghezza dei filtri FIR sintetizzati (Nh > Nc)
% h_matrix  = filtro inverso sintetizzato (Nh)

function h_matrix = invert_kirkeby(c_matrix,Fs,fl,fh,bt,Bol,Boh,Bi,Nh)

%display(sprintf('Inversione delle risposte all''impulso secondo Kirkeby:'))
    
Nc = size(c_matrix);

%********************* Calcolo di C(k) ********************

%display(sprintf('\t- Trasformazione nel dominio della frequenza...'))

%Trasformata delle risposte all'impulso sul numero di campioni desiderati per i filtri
C_matrix = fft(c_matrix,Nh);
%Mantieni solo le prime Nh/2+1 righe spettrali per risparmiare memoria 
C_matrix = C_matrix(1:Nh/2+1);
clear c_matrix


%********************* Calcolo di B(k) *********************

%display(sprintf('\t- Calcolo del parametro di regolarizzazione...'))

% Profilo del parametro Beta al variare della frequenza
%     A
%  Boh|                                   -------
%  Bol+------                            / 
%     |       \                         /
%     |         \                     /
%     |           \                 /
%  Bi +             ---------------
%     +-----+---+---+-------------+---+---+------+---->
%     0    fl1  fl fl2           fh1  fh fh2    Fs/2
                
%Calcolo delle frequenze di transizione
fl1 = fl / (2^(bt/2));
fl2 = fl * (2^(bt/2));
fh1 = fh / (2^(bt/2));
fh2 = fh * (2^(bt/2));

%Quantizzazione dele frequenze di transizione
df = Fs/Nh;
kl1 = round(fl1/df);
kl2 = round(fl2/df)+1;
kh1 = round(fh1/df);
kh2 = min(round(fh2/df)+1,Nh/2);

%Creazione del profilo di B in funzione della frequenza
%B � quindi un vettore con Nh/2+1 elementi (basta rappresentarlo per le frequenze positive)
B = [ones(1,kl1).*Bol, linspace(Bol,Bi,kl2-kl1), ones(1,kh1-kl2).*Bi, linspace(Bi,Boh,kh2-kh1), ones(1,(Nh/2+1)-kh2).*Boh ];


%********************* Inversione nel dominio della frequenza *********************

%NOTA: I segnali audio nel dominio del tempo sono ovviamente reali, i loro spettri godono quindi di simmetria hermitiana.
%      Possiamo quindi eseguire il calcolo del filtro inverso H solo per le prime N/2+1 righe spettrali dell'fft 
%      (che in Matlab corrispondono alle frequenze positive) e ottenere le restanti per simmetria.
% in realt� la frequenza 1 rappresenta la DC e la frequenza Nh/2+1 rappresenta la Fs e non possono essere rifasate...quindi vengono fissate a 0

%display(sprintf('\t- Inversione...'))

%Inizializza matrici
H_matrix = zeros(Nh,1); 
R_matrix = zeros(Nh/2+1,1);
warning('OFF','MATLAB:nearlySingularMatrix')

S = Nh/2;    %Ritardo di causalizzazione

%Calcola R e H per ogni riga spettrale
%(Salta righe spettrali DC e Fs impostate a 0 durante l'inizializzazione)
for k = 2 : (Nh/2)
    %Forma adatta all'esportazione (Avoid use of inv that is deprecated by MATLAB)
    H_matrix(k) = ( (C_matrix(k)')*C_matrix(k) + B(k) ) \ (C_matrix(k)') .* (1/2)*exp(-j*2*pi*(k-1)*((S+1)-1)/Nh);
end

%Elimina matrici non pi� utilizzate per risparmiare memoria
clear C_matrix

%Rendi hermitiana la matrice H 
H_matrix(Nh/2+1:Nh) = [0; conj( flipud( squeeze(H_matrix(2:Nh/2)) ) )];

%********************* Calcolo di h(n) *********************

%display(sprintf('\t- Antitrasformazione delle funzioni di trasferimento...'))
h_matrix = ifft(H_matrix,Nh);        
clear H_matrix

% shorten the filter
Nh=Nh/2;
h_matrix=h_matrix(1:Nh);
%display(sprintf('\t- Finestratura dei filtri FIR...'))

%Costruisci la finestra
twin = hann(Nh/2);
window = [twin(1:floor(Nh/4));ones(floor(Nh/2),1);twin(floor(Nh/4)+1:floor(Nh/2))];
window = [window ; zeros(size(h_matrix,3)-size(window,1),1)];

%Applica la finestra
h_matrix(:) = squeeze(h_matrix(:)).*window;



