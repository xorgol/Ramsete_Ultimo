This directory contains the Beta version of the Ramsete Binaural Converter
The three files below must be copied inside the Ramsete install directory:
- audiocnv.exe (substitutes the original file with the same name)
- RAM2WAV4.exe (the conversion program from Ramsete to WAV)
- compact.wav (the complete set of binaural impulse responses measured by 
  Bill Gardner at MIT-Medialab)
Please report to the author (farina@pcfarina.eng.unipr.it) about any bugs
contained in this Beta software.