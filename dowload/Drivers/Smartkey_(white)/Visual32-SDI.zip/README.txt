EUTRON SPA
INFORMATION SECURITY SOLUTION

Phone +39-(0)35-697011
Fax   +39-(0)35-697092

Internet : http://www.smartkey.eutron.com
Technical support : helpdesk@eutron.com
Commercial info : info@eutron.com


SMARTKEY DRIVER INSTALLATION
----------------------------

This package contains an installation library for the SmartKey drivers.

The file "skeyinst.dll" is the installation library. The exported functions are 
defined in the "skeyinst.h" file.
The documentation is present in HTML format in the archive "skeyinst-html.zip"
and in CHM format in the file "skeyinst.chm".

The file "sdi.exe" is a simple example application that uses the library.

The "skeyinst-installshield631.zip" file contains a complete install example for 
InstallShield 6.31.

All the others *.sys and *.inf files are the drivers required for the 
installation.
